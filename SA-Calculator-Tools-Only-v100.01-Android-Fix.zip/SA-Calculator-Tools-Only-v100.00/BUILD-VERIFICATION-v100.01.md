# Build verification — v100.01

- Release identity: `2.0.1-v100.01`
- Android versionCode: `1099140`
- Unique tools: 12
- Automated regression tests: **55 passed, 0 failed**
- JavaScript syntax checks: passed
- Android web bundle generation: passed
- Workflow YAML parsing: passed
- Embedded and standalone workflow files: byte-for-byte identical
- Android native project generation: configured to run on a clean GitHub runner via `npm run android:setup`
- Gradle APK compilation and APK artifact: **pending GitHub Actions execution**
- Physical Android installation/runtime test: pending

The ZIP does not claim an APK has already been built. The workflow creates the Capacitor Android project, syncs the web bundle, patches native branding/version/insets, runs Gradle, verifies the APK and uploads it as an artifact.
