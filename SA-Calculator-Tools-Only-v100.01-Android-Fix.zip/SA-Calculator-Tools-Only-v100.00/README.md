# SA Calculator — Tools Only v100.01

A focused Android app that opens directly into the 12-tool catalogue. Home, standalone calculator, Settings, Favorites, History and navigation destinations are not exposed in this tools-only edition.

## Tools
- Finance & Money: GST/VAT, Loan, Saving, Salary, Tip, SIP, Currency, Discount
- Math & General Utilities: Percentage, Unit Converter
- Health: Age, BMI

The shared numeric keypad and calculation engine remain internal dependencies used by tool forms.

## Android APK build
Requires Node.js 22, Java 21 and Android SDK platform/build-tools 35.

1. `npm install --no-package-lock --no-audit --no-fund`
2. `npm run test:release`
3. `npm run android:setup` — builds web assets, creates `android/` if absent, syncs Capacitor and applies native branding/version.
4. `cd android && ./gradlew assembleDebug`
5. APK: `android/app/build/outputs/apk/debug/app-debug.apk`

GitHub Actions workflow: `.github/workflows/main.yml`. It generates the Android project on a clean runner and uploads the APK as a workflow artifact.
