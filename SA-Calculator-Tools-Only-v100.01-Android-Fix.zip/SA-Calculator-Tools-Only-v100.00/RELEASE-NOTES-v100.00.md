# Release v100.00 — Tools Only

- Rebuilt as a tools-only Android/web app.
- Startup is forced to the categorized Tools catalogue; previous Home/Calculator startup preferences are ignored.
- Home, standalone Calculator, Settings, Favorites, History, drawer and bottom navigation are not exposed.
- Preserved all 12 tool destinations and their calculation/conversion workspaces.
- Preserved the shared keypad as an internal dependency for numeric tool forms.
- Added a dedicated responsive tools-only stylesheet and included it in the offline cache and Android web bundle.
- Added release identity, 12-tool catalogue, startup routing, responsive layout and bundle checks.
